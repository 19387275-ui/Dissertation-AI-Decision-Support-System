import pandas as pd
from pathlib import Path

# Create output directory
Path("outputs/summaries").mkdir(parents=True, exist_ok=True)

# Load dataset
df = pd.read_csv("dataset/loan_approval_dataset.csv")

# Remove extra spaces from column names
df.columns = df.columns.str.strip()

with open("outputs/summaries/dataset_summary.txt", "w", encoding="utf-8") as f:

    f.write("LOAN STATUS DISTRIBUTION\n")
    f.write(df["loan_status"].value_counts().to_string())
    f.write("\n\n")

    f.write("EDUCATION DISTRIBUTION\n")
    f.write(df["education"].value_counts().to_string())
    f.write("\n\n")

    f.write("SELF EMPLOYED DISTRIBUTION\n")
    f.write(df["self_employed"].value_counts().to_string())
    f.write("\n\n")

    f.write("DEPENDENTS DISTRIBUTION\n")
    f.write(df["no_of_dependents"].value_counts().sort_index().to_string())
    f.write("\n\n")

print("Dataset summary saved successfully.")