import pandas as pd
from pathlib import Path

# Create output folder
Path("outputs/summaries").mkdir(parents=True, exist_ok=True)

# Load dataset
df = pd.read_csv("dataset/loan_approval_dataset.csv")

# Remove extra spaces from column names
df.columns = df.columns.str.strip()

# Save results file
with open("outputs/summaries/dataset_exploration.txt", "w", encoding="utf-8") as f:

    f.write("FIRST 5 RECORDS\n")
    f.write(df.head().to_string())
    f.write("\n\n")

    f.write("DATASET SHAPE\n")
    f.write(str(df.shape))
    f.write("\n\n")

    f.write("COLUMN NAMES\n")
    f.write(str(df.columns.tolist()))
    f.write("\n\n")

    f.write("DATA TYPES\n")
    f.write(df.dtypes.to_string())
    f.write("\n\n")

    f.write("MISSING VALUES\n")
    f.write(df.isnull().sum().to_string())
    f.write("\n\n")

    f.write("STATISTICAL SUMMARY\n")
    f.write(df.describe().to_string())
    f.write("\n\n")

    f.write("LOAN STATUS DISTRIBUTION\n")
    f.write(df["loan_status"].value_counts().to_string())

print("Dataset exploration completed.")
print("Results saved to:")
print("outputs/summaries/dataset_exploration.txt")