import pandas as pd
import joblib

from sklearn.neighbors import NearestNeighbors

CASE_BASE_PATH = "outputs/processed_data/case_base.csv"

SCALER_PATH = "outputs/processed_data/minmax_scaler.pkl"

FEATURE_COLUMNS = [
    "no_of_dependents",
    "education",
    "self_employed",
    "income_annum",
    "loan_amount",
    "loan_term",
    "cibil_score",
    "residential_assets_value",
    "commercial_assets_value",
    "luxury_assets_value",
    "bank_asset_value"
]


def build_cbr_model():

    df = pd.read_csv(
        CASE_BASE_PATH
    )

    X = df[FEATURE_COLUMNS]

    knn = NearestNeighbors(
        n_neighbors=5,
        metric="euclidean"
    )

    knn.fit(X)

    return df, knn


def scale_applicant_data(applicant_data):

    scaler = joblib.load(
        SCALER_PATH
    )

    numerical_data = pd.DataFrame(
        [[
            applicant_data["no_of_dependents"],
            applicant_data["income_annum"],
            applicant_data["loan_amount"],
            applicant_data["loan_term"],
            applicant_data["cibil_score"],
            applicant_data["residential_assets_value"],
            applicant_data["commercial_assets_value"],
            applicant_data["luxury_assets_value"],
            applicant_data["bank_asset_value"]
        ]],
        columns=[
            "no_of_dependents",
            "income_annum",
            "loan_amount",
            "loan_term",
            "cibil_score",
            "residential_assets_value",
            "commercial_assets_value",
            "luxury_assets_value",
            "bank_asset_value"
        ]
    )

    scaled_values = scaler.transform(
        numerical_data
    )[0]

    scaled_applicant = [
        scaled_values[0],
        applicant_data["education"],
        applicant_data["self_employed"],
        scaled_values[1],
        scaled_values[2],
        scaled_values[3],
        scaled_values[4],
        scaled_values[5],
        scaled_values[6],
        scaled_values[7],
        scaled_values[8]
    ]

    return scaled_applicant


def get_recommendation(applicant_data):

    df, knn = build_cbr_model()

    applicant_df = pd.DataFrame(
        [applicant_data],
        columns=FEATURE_COLUMNS
    )

    distances, indices = knn.kneighbors(
        applicant_df
    )

    similar_cases = df.iloc[
        indices[0]
    ].copy()

    similar_cases["distance"] = (
        distances[0]
    )

    similar_cases["similarity_percent"] = (
        1 / (1 + similar_cases["distance"])
    ) * 100

    approved_count = int(
        similar_cases["loan_status"].sum()
    )

    rejected_count = (
        len(similar_cases)
        - approved_count
    )

    if approved_count >= 3:
        recommendation = "APPROVED"
    else:
        recommendation = "REJECTED"

    confidence = (
        max(
            approved_count,
            rejected_count
        )
        / len(similar_cases)
    ) * 100

    return {
        "recommendation": recommendation,
        "confidence": confidence,
        "approved_neighbours": approved_count,
        "rejected_neighbours": rejected_count,
        "similar_cases": similar_cases
    }


if __name__ == "__main__":

    applicant_data = {
        "no_of_dependents": 2,
        "education": 1,
        "self_employed": 0,
        "income_annum": 5000000,
        "loan_amount": 15000000,
        "loan_term": 10,
        "cibil_score": 750,
        "residential_assets_value": 5000000,
        "commercial_assets_value": 3000000,
        "luxury_assets_value": 10000000,
        "bank_asset_value": 4000000
    }

    scaled_input = scale_applicant_data(
        applicant_data
    )

    result = get_recommendation(
        scaled_input
    )

    print("\nTop 5 Similar Cases")

    print(
        result["similar_cases"][
            [
                "case_id",
                "loan_status",
                "distance",
                "similarity_percent"
            ]
        ]
    )

    print(
        "\nApproved Neighbours:",
        result["approved_neighbours"]
    )

    print(
        "Rejected Neighbours:",
        result["rejected_neighbours"]
    )

    print(
        f"\nConfidence Score: "
        f"{result['confidence']:.2f}%"
    )

    print(
        "\nFinal Recommendation:"
    )

    print(
        result["recommendation"]
    )