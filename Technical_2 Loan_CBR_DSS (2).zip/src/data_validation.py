import pandas as pd

df = pd.read_csv("dataset/loan_approval_dataset.csv")

df.columns = df.columns.str.strip()

print("\nNEGATIVE VALUES CHECK\n")

numeric_columns = [
    "income_annum",
    "loan_amount",
    "loan_term",
    "cibil_score",
    "residential_assets_value",
    "commercial_assets_value",
    "luxury_assets_value",
    "bank_asset_value"
]

for col in numeric_columns:
    negatives = (df[col] < 0).sum()
    print(f"{col}: {negatives}")