import pandas as pd
from pathlib import Path

# Create output folder
Path("outputs/processed_data").mkdir(
    parents=True,
    exist_ok=True
)

print("Loading processed dataset...")

# Load processed data
df = pd.read_csv(
    "outputs/processed_data/processed_loan_dataset.csv"
)

# Create Case ID

df.insert(
    0,
    "case_id",
    range(1, len(df) + 1)
)

# Save case repository

df.to_csv(
    "outputs/processed_data/case_base.csv",
    index=False
)

print("\nCase Base Created Successfully")

print("\nTotal Cases:")
print(len(df))

print("\nCase Base Preview")
print(df.head())