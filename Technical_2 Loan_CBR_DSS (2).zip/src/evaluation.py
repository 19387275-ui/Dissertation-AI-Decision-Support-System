import pandas as pd
from pathlib import Path

from sklearn.model_selection import train_test_split
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix
)

Path("outputs/evaluation").mkdir(
    parents=True,
    exist_ok=True
)

print("Loading case base...")

df = pd.read_csv(
    "outputs/processed_data/case_base.csv"
)

feature_columns = [
    "no_of_dependents",
    "education",
    "self_employed",
    "income_annum",
    "loan_amount",
    "loan_term",
    "cibil_score",
    "residential_assets_value",
    "commercial_assets_value",
    "luxury_assets_value",
    "bank_asset_value"
]

X = df[feature_columns]

y = df["loan_status"]

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

knn = NearestNeighbors(
    n_neighbors=5,
    metric="euclidean"
)

knn.fit(X_train)

predictions = []

for i in range(len(X_test)):

    test_case = X_test.iloc[[i]]

    distances, indices = knn.kneighbors(
        test_case
    )

    neighbour_labels = y_train.iloc[
        indices[0]
    ]

    approved_count = neighbour_labels.sum()

    if approved_count >= 3:
        predictions.append(1)
    else:
        predictions.append(0)

accuracy = accuracy_score(
    y_test,
    predictions
)

precision = precision_score(
    y_test,
    predictions
)

recall = recall_score(
    y_test,
    predictions
)

f1 = f1_score(
    y_test,
    predictions
)

cm = confusion_matrix(
    y_test,
    predictions
)

results_df = pd.DataFrame({
    "Actual": y_test.values,
    "Predicted": predictions
})

results_df.to_csv(
    "outputs/evaluation/predictions.csv",
    index=False
)

with open(
    "outputs/evaluation/evaluation_results.txt",
    "w",
    encoding="utf-8"
) as f:

    f.write("CBR SYSTEM EVALUATION\n\n")

    f.write(
        f"Accuracy : {accuracy:.4f}\n"
    )

    f.write(
        f"Precision: {precision:.4f}\n"
    )

    f.write(
        f"Recall   : {recall:.4f}\n"
    )

    f.write(
        f"F1 Score : {f1:.4f}\n\n"
    )

    f.write("Confusion Matrix\n")

    f.write(
        str(cm)
    )

print("\nCBR SYSTEM EVALUATION")

print(
    f"\nAccuracy : {accuracy:.4f}"
)

print(
    f"Precision: {precision:.4f}"
)

print(
    f"Recall   : {recall:.4f}"
)

print(
    f"F1 Score : {f1:.4f}"
)

print("\nConfusion Matrix")

print(cm)

print(
    "\nEvaluation results saved to:"
)

print(
    "outputs/evaluation/evaluation_results.txt"
)

print(
    "\nPredictions saved to:"
)

print(
    "outputs/evaluation/predictions.csv"
)