import pandas as pd
import joblib
from pathlib import Path
from sklearn.preprocessing import MinMaxScaler


# Create Output Folders


Path("outputs/processed_data").mkdir(parents=True, exist_ok=True)
Path("outputs/summaries").mkdir(parents=True, exist_ok=True)

print("Loading dataset...")


# Load Dataset


df = pd.read_csv("dataset/loan_approval_dataset.csv")

# Remove spaces from column names
df.columns = df.columns.str.strip()


# Clean Text Columns


text_columns = [
    "education",
    "self_employed",
    "loan_status"
]

for col in text_columns:
    df[col] = df[col].astype(str).str.strip()


# Dataset Information Before Processing


original_shape = df.shape


# Remove ID Column


df = df.drop("loan_id", axis=1)


# Encode Categorical Variables


df["education"] = df["education"].map({
    "Graduate": 1,
    "Not Graduate": 0
})

df["self_employed"] = df["self_employed"].map({
    "Yes": 1,
    "No": 0
})

df["loan_status"] = df["loan_status"].map({
    "Approved": 1,
    "Rejected": 0
})


# Validate Encoding


print("\nEncoded Education Values")
print(df["education"].unique())

print("\nEncoded Self Employed Values")
print(df["self_employed"].unique())

print("\nEncoded Loan Status Values")
print(df["loan_status"].unique())

# Check for encoding failures

education_nulls = df["education"].isnull().sum()
employment_nulls = df["self_employed"].isnull().sum()
status_nulls = df["loan_status"].isnull().sum()


# Negative Asset Investigation


negative_residential = (
    df["residential_assets_value"] < 0
).sum()

print("\nNegative Residential Asset Records:")
print(negative_residential)

# Replace negative values with 0

df["residential_assets_value"] = (
    df["residential_assets_value"]
    .clip(lower=0)
)


# Scale Numerical Features


numerical_columns = [
    "no_of_dependents",
    "income_annum",
    "loan_amount",
    "loan_term",
    "cibil_score",
    "residential_assets_value",
    "commercial_assets_value",
    "luxury_assets_value",
    "bank_asset_value"
]

scaler = MinMaxScaler()

df[numerical_columns] = scaler.fit_transform(
    df[numerical_columns]
)

joblib.dump(
    scaler,
    "outputs/processed_data/minmax_scaler.pkl"
)

print(
    "\nScaler saved successfully."
)

# Save Processed Dataset


processed_file = (
    "outputs/processed_data/"
    "processed_loan_dataset.csv"
)

df.to_csv(
    processed_file,
    index=False
)


# Save Preprocessing Report


with open(
    "outputs/summaries/preprocessing_report.txt",
    "w",
    encoding="utf-8"
) as report:

    report.write(
        "PREPROCESSING REPORT\n"
    )

    report.write(
        "\nOriginal Dataset Shape:\n"
    )
    report.write(str(original_shape))

    report.write(
        "\n\nProcessed Dataset Shape:\n"
    )
    report.write(str(df.shape))

    report.write(
        "\n\nEncoding Validation\n"
    )

    report.write(
        f"\nEducation Null Values: "
        f"{education_nulls}"
    )

    report.write(
        f"\nSelf Employed Null Values: "
        f"{employment_nulls}"
    )

    report.write(
        f"\nLoan Status Null Values: "
        f"{status_nulls}"
    )

    report.write(
        f"\n\nNegative Residential "
        f"Asset Records Found: "
        f"{negative_residential}"
    )

    report.write(
        "\nNegative values replaced "
        "with 0."
    )


# Display Results


print("\nPreprocessing completed successfully.")

print("\nProcessed Dataset Saved:")
print(processed_file)

print("\nPreprocessing Report Saved:")
print(
    "outputs/summaries/"
    "preprocessing_report.txt"
)

print("\nFirst 5 Processed Records")
print(df.head())