import streamlit as st
import pandas as pd

from pathlib import Path
from datetime import datetime

from cbr_model import (
    get_recommendation,
    scale_applicant_data
)


def save_recommendation(
    applicant_data,
    result
):

    history_file = (
        "outputs/recommendations/"
        "recommendation_history.csv"
    )

    record = {
        "timestamp": datetime.now(),
        "dependents": applicant_data[
            "no_of_dependents"
        ],
        "education": applicant_data[
            "education"
        ],
        "self_employed": applicant_data[
            "self_employed"
        ],
        "income_annum": applicant_data[
            "income_annum"
        ],
        "loan_amount": applicant_data[
            "loan_amount"
        ],
        "loan_term": applicant_data[
            "loan_term"
        ],
        "cibil_score": applicant_data[
            "cibil_score"
        ],
        "recommendation": result[
            "recommendation"
        ],
        "confidence": round(
            result["confidence"],
            2
        )
    }

    new_record = pd.DataFrame(
        [record]
    )

    if Path(
        history_file
    ).exists():

        existing = pd.read_csv(
            history_file
        )

        updated = pd.concat(
            [existing, new_record],
            ignore_index=True
        )

        updated.to_csv(
            history_file,
            index=False
        )

    else:

        new_record.to_csv(
            history_file,
            index=False
        )


st.set_page_config(
    page_title="Loan Approval Decision Support System",
    page_icon="🏦",
    layout="wide"
)

Path(
    "outputs/recommendations"
).mkdir(
    parents=True,
    exist_ok=True
)

st.title(
    "AI-Based Loan Approval Decision Support System"
)

st.markdown(
    "Case-Based Reasoning (CBR) Recommendation Engine"
)

st.sidebar.header(
    "System Performance"
)

st.sidebar.metric(
    "Accuracy",
    "90.75%"
)

st.sidebar.metric(
    "Precision",
    "91.70%"
)

st.sidebar.metric(
    "Recall",
    "93.60%"
)

st.sidebar.metric(
    "F1 Score",
    "92.64%"
)

st.subheader(
    "Applicant Information"
)

col1, col2 = st.columns(2)

with col1:

    no_of_dependents = st.number_input(
        "Number of Dependents",
        min_value=0,
        max_value=5,
        value=2
    )

    education = st.selectbox(
        "Education",
        [
            "Graduate",
            "Not Graduate"
        ]
    )

    self_employed = st.selectbox(
        "Self Employed",
        [
            "No",
            "Yes"
        ]
    )

    income_annum = st.number_input(
        "Annual Income",
        min_value=200000,
        max_value=10000000,
        value=5000000,
        step=100000
    )

    loan_amount = st.number_input(
        "Loan Amount Requested",
        min_value=300000,
        max_value=40000000,
        value=15000000,
        step=100000
    )

with col2:

    loan_term = st.number_input(
        "Loan Term",
        min_value=2,
        max_value=20,
        value=10
    )

    cibil_score = st.number_input(
        "CIBIL Score",
        min_value=300,
        max_value=900,
        value=750
    )

    residential_assets_value = st.number_input(
        "Residential Assets Value",
        min_value=0,
        max_value=30000000,
        value=5000000,
        step=100000
    )

    commercial_assets_value = st.number_input(
        "Commercial Assets Value",
        min_value=0,
        max_value=20000000,
        value=3000000,
        step=100000
    )

    luxury_assets_value = st.number_input(
        "Luxury Assets Value",
        min_value=0,
        max_value=40000000,
        value=10000000,
        step=100000
    )

bank_asset_value = st.number_input(
    "Bank Asset Value",
    min_value=0,
    max_value=15000000,
    value=4000000,
    step=100000
)

if st.button(
    "Get Recommendation"
):

    applicant_data = {
        "no_of_dependents":
            no_of_dependents,

        "education":
            1 if education ==
            "Graduate" else 0,

        "self_employed":
            1 if self_employed ==
            "Yes" else 0,

        "income_annum":
            income_annum,

        "loan_amount":
            loan_amount,

        "loan_term":
            loan_term,

        "cibil_score":
            cibil_score,

        "residential_assets_value":
            residential_assets_value,

        "commercial_assets_value":
            commercial_assets_value,

        "luxury_assets_value":
            luxury_assets_value,

        "bank_asset_value":
            bank_asset_value
    }

    scaled_input = (
        scale_applicant_data(
            applicant_data
        )
    )

    result = (
        get_recommendation(
            scaled_input
        )
    )

    save_recommendation(
        applicant_data,
        result
    )

    st.subheader(
        "Decision Recommendation"
    )

    if (
        result["recommendation"]
        == "APPROVED"
    ):

        st.success(
            "Loan Recommended for Approval"
        )

    else:

        st.error(
            "Loan Recommended for Rejection"
        )

    st.metric(
        "Confidence Score",
        f"{result['confidence']:.2f}%"
    )

    metric_col1, metric_col2 = (
        st.columns(2)
    )

    with metric_col1:

        st.metric(
            "Approved Neighbours",
            result[
                "approved_neighbours"
            ]
        )

    with metric_col2:

        st.metric(
            "Rejected Neighbours",
            result[
                "rejected_neighbours"
            ]
        )

    st.subheader(
        "Top 5 Similar Historical Cases"
    )

    similar_cases = (
        result["similar_cases"][
            [
                "case_id",
                "loan_status",
                "similarity_percent"
            ]
        ].copy()
    )

    similar_cases[
        "loan_status"
    ] = (
        similar_cases[
            "loan_status"
        ].map({
            1: "Approved",
            0: "Rejected"
        })
    )

    similar_cases.rename(
        columns={
            "case_id":
                "Case ID",

            "loan_status":
                "Decision",

            "similarity_percent":
                "Similarity (%)"
        },
        inplace=True
    )

    similar_cases[
        "Similarity (%)"
    ] = (
        similar_cases[
            "Similarity (%)"
        ].round(2)
    )

    st.dataframe(
        similar_cases,
        use_container_width=True
    )

history_file = (
    "outputs/recommendations/"
    "recommendation_history.csv"
)

if Path(
    history_file
).exists():

    st.sidebar.subheader(
        "Recent Recommendations"
    )

    history = pd.read_csv(
        history_file
    )

    st.sidebar.dataframe(
        history.tail(10),
        use_container_width=True
    )